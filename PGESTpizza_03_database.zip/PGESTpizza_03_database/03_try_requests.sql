-- Retrouver le contenu de la commande numéro 1

SELECT Commande.id AS numero_de_commande, Pizza.nom AS nom_pizza, Panier.prix_pizza, Panier.quantite
FROM Pizza
JOIN Panier
ON Pizza.id = Panier.pizza_id
JOIN commande
ON Panier.commande_id = Commande.id
WHERE Commande.id = 1;

-- Quelles sont les commandes en attente préparation dans le retaurant numéro 6 et à partir de quand ?

SELECT Commande.id AS numero_de_commande, Statut.position, Progression.date_debut
FROM Commande
JOIN Progression
ON Commande.id = Progression.commande_id
JOIN Statut
ON Progression.statut_id = Statut.id
WHERE Commande.restaurant_id = 6 and Statut.position = 'En attente de préparation';

-- Quelles sont les commandes en attente pour le client Karim Belkacem et quel statut dans le flux de livraison?

SELECT Commande.id AS numero_de_commande, Statut.position, Progression.date_debut
FROM Utilisateur
JOIN Delai
ON Utilisateur.id = Delai.utilisateur_id
JOIN Commande
ON Delai.commande_id = Commande.id
JOIN Progression
ON Commande.id = Progression.commande_id
JOIN Statut
ON Progression.statut_id = Statut.id
WHERE Utilisateur.nom = 'Belkacem' and Utilisateur.prenom = 'Karim' and Statut.position != 'Terminée';

-- Retrouver l'adresse d'une commande terminée donnée
 SELECT Commande.id AS reference_commande, Adresse.numero, Adresse.rue, Adresse.code_postal, 
 Adresse.batiment, Adresse.etage, Adresse.digicode
 FROM Commande
 JOIN Adresse
 ON Commande.adresse_id = Adresse.id
 WHERE Commande.id = 1;

-- Retrouver le prix, le nom de resto d'une pizza donnée et la date de commande dans une commande terminée donnée
-- Vérifier le prix actuel et son évolution dans le temps, dans le même restaurant pour la même pizza
 SELECT Pizza.nom AS nom_pizza, Panier.prix_pizza AS prix_commande, Progression.date_debut AS data_commande,
 Tarif.prix_pizza AS prix_actuel, tarif.date_tarif, Restaurant.nom AS nom_resto
 FROM Commande
 JOIN Panier
 ON Commande.id = Panier.commande_id
 JOIN Pizza
 ON Panier.pizza_id = Pizza.id
 JOIN Restaurant
 ON Commande.restaurant_id = Restaurant.id
 JOIN Progression
 ON Commande.id = Progression.commande_id
 JOIN Tarif
 ON Pizza.id = Tarif.pizza_id
 WHERE commande.id = 2 and Panier.pizza_id = 5
 ORDER BY tarif.date_tarif;

-- Lister les pizzas pour lesquelles le niveau de stock ne permet pas de les produire et dans quel restaurant
SELECT Pizza.nom AS nom_pizza, Restaurant.nom AS nom_resto
FROM Pizza
JOIN Recette
ON Pizza.id = Recette.pizza_id
JOIN Ingredient
ON Recette.ingredient_id = Ingredient.id
JOIN Stock 
ON Ingredient.id = Stock.ingredient_id
JOIN Restaurant
ON Stock.restaurant_id = Restaurant.id
WHERE Stock.poids_kg = 0;


