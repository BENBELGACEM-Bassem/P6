-- MySQL Workbench Synchronization
-- Generated: 2020-07-22 08:05
-- Model: New Model
-- Version: 1.0
-- Project: Name of the project
-- Author: Admin

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

ALTER SCHEMA `oc_pizza_db`  DEFAULT CHARACTER SET utf8  DEFAULT COLLATE utf8_general_ci ;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Restaurant` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NULL DEFAULT NULL,
  `telephone` VARCHAR(255) NOT NULL,
  `adresse_id` INT(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Restaurant_Adresse` (`adresse_id` ASC) VISIBLE,
  CONSTRAINT `fk_Restaurant_Adresse`
    FOREIGN KEY (`adresse_id`)
    REFERENCES `oc_pizza_db`.`Adresse` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Ingredient` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Pizza` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Commande` (
  `id` BIGINT(19) UNSIGNED NOT NULL AUTO_INCREMENT,
  `adresse_id` INT(10) UNSIGNED NOT NULL,
  `restaurant_id` INT(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Commande_Adresse` (`adresse_id` ASC) VISIBLE,
  INDEX `fk_Commande_Restaurant_idx` (`restaurant_id` ASC) VISIBLE,
  CONSTRAINT `fk_Commande_Adresse`
    FOREIGN KEY (`adresse_id`)
    REFERENCES `oc_pizza_db`.`Adresse` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Commande_Restaurant`
    FOREIGN KEY (`restaurant_id`)
    REFERENCES `oc_pizza_db`.`Restaurant` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Utilisateur` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(100) NOT NULL,
  `prenom` VARCHAR(100) NOT NULL,
  `civilite` CHAR(1) NULL DEFAULT NULL,
  `email` VARCHAR(255) NOT NULL,
  `telephone` VARCHAR(255) NOT NULL,
  `mot_de_passe` TEXT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Stock` (
  `restaurant_id` INT(10) UNSIGNED NOT NULL,
  `ingredient_id` INT(10) UNSIGNED NOT NULL,
  `poids_kg` DECIMAL(4,1) NOT NULL,
  `date_inventaire` DATETIME NOT NULL,
  PRIMARY KEY (`restaurant_id`, `ingredient_id`),
  INDEX `fk_Stock_Restaurant_idx` (`restaurant_id` ASC) VISIBLE,
  INDEX `fk_Stock_Ingredient1_idx` (`ingredient_id` ASC) VISIBLE,
  CONSTRAINT `fk_Stock_Restaurant`
    FOREIGN KEY (`restaurant_id`)
    REFERENCES `oc_pizza_db`.`Restaurant` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Stock_Ingredient1`
    FOREIGN KEY (`ingredient_id`)
    REFERENCES `oc_pizza_db`.`Ingredient` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Tarif` (
  `restaurant_id` INT(10) UNSIGNED NOT NULL,
  `pizza_id` INT(10) UNSIGNED NOT NULL,
  `prix_pizza` DECIMAL(3,1) NOT NULL,
  `date_tarif` DATETIME NOT NULL,
  PRIMARY KEY (`restaurant_id`, `pizza_id`),
  INDEX `fk_Tarif_Restaurant1_idx` (`restaurant_id` ASC) VISIBLE,
  INDEX `fk_Tarif_Pizza1_idx` (`pizza_id` ASC) VISIBLE,
  CONSTRAINT `fk_Tarif_Restaurant1`
    FOREIGN KEY (`restaurant_id`)
    REFERENCES `oc_pizza_db`.`Restaurant` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Tarif_Pizza1`
    FOREIGN KEY (`pizza_id`)
    REFERENCES `oc_pizza_db`.`Pizza` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Recette` (
  `pizza_id` INT(10) UNSIGNED NOT NULL,
  `ingredient_id` INT(10) UNSIGNED NOT NULL,
  `poids_gr` DECIMAL(4,1) NOT NULL,
  PRIMARY KEY (`pizza_id`, `ingredient_id`),
  INDEX `fk_Recette_Ingredient1_idx` (`ingredient_id` ASC) VISIBLE,
  INDEX `fk_Recette_Pizza1_idx` (`pizza_id` ASC) VISIBLE,
  CONSTRAINT `fk_Recette_Ingredient1`
    FOREIGN KEY (`ingredient_id`)
    REFERENCES `oc_pizza_db`.`Ingredient` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Recette_Pizza1`
    FOREIGN KEY (`pizza_id`)
    REFERENCES `oc_pizza_db`.`Pizza` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Panier` (
  `commande_id` BIGINT(19) UNSIGNED NOT NULL,
  `pizza_id` INT(10) UNSIGNED NOT NULL,
  `prix_pizza` DECIMAL(3,1) NOT NULL,
  `quantite` INT(11) NOT NULL,
  PRIMARY KEY (`commande_id`, `pizza_id`),
  INDEX `fk_Panier_Pizza1_idx` (`pizza_id` ASC) VISIBLE,
  INDEX `fk_Panier_Commande1_idx` (`commande_id` ASC) VISIBLE,
  CONSTRAINT `fk_Panier_Pizza1`
    FOREIGN KEY (`pizza_id`)
    REFERENCES `oc_pizza_db`.`Pizza` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Panier_Commande1`
    FOREIGN KEY (`commande_id`)
    REFERENCES `oc_pizza_db`.`Commande` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Delai` (
  `commande_id` BIGINT(19) UNSIGNED NOT NULL,
  `utilisateur_id` INT(10) UNSIGNED NOT NULL,
  `echeance` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`commande_id`, `utilisateur_id`),
  INDEX `fk_Delai_Commande1_idx` (`commande_id` ASC) VISIBLE,
  INDEX `fk_Delai_Utilisateur1_idx` (`utilisateur_id` ASC) VISIBLE,
  CONSTRAINT `fk_Delai_Commande1`
    FOREIGN KEY (`commande_id`)
    REFERENCES `oc_pizza_db`.`Commande` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Delai_Utilisateur1`
    FOREIGN KEY (`utilisateur_id`)
    REFERENCES `oc_pizza_db`.`Utilisateur` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Cout` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `prix_100gr` DECIMAL(3,1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `prix_100gr_UNIQUE` (`prix_100gr` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Course` (
  `ingredient_id` INT(10) UNSIGNED NOT NULL,
  `cout_id` INT(10) UNSIGNED NOT NULL,
  `date_achat` DATETIME NOT NULL,
  PRIMARY KEY (`ingredient_id`, `cout_id`),
  INDEX `fk_Course_Ingredient1_idx` (`ingredient_id` ASC) VISIBLE,
  INDEX `fk_Course_Cout1_idx` (`cout_id` ASC) VISIBLE,
  CONSTRAINT `fk_Course_Ingredient1`
    FOREIGN KEY (`ingredient_id`)
    REFERENCES `oc_pizza_db`.`Ingredient` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Course_Cout1`
    FOREIGN KEY (`cout_id`)
    REFERENCES `oc_pizza_db`.`Cout` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Statut` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `position` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Progression` (
  `commande_id` BIGINT(19) UNSIGNED NOT NULL,
  `statut_id` INT(10) UNSIGNED NOT NULL,
  `date_debut` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`commande_id`, `statut_id`),
  INDEX `fk_Progression_Commande1_idx` (`commande_id` ASC) VISIBLE,
  INDEX `fk_Progression_Statut1_idx` (`statut_id` ASC) VISIBLE,
  CONSTRAINT `fk_Progression_Commande1`
    FOREIGN KEY (`commande_id`)
    REFERENCES `oc_pizza_db`.`Commande` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Progression_Statut1`
    FOREIGN KEY (`statut_id`)
    REFERENCES `oc_pizza_db`.`Statut` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Adresse` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `numero` VARCHAR(5) NOT NULL,
  `rue` VARCHAR(150) NOT NULL,
  `code_postal` VARCHAR(5) NOT NULL,
  `batiment` VARCHAR(5) NULL DEFAULT NULL,
  `etage` VARCHAR(5) NULL DEFAULT NULL,
  `digicode` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Localisation` (
  `utilisateur_id` INT(10) UNSIGNED NOT NULL,
  `adresse_id` INT(10) UNSIGNED NOT NULL,
  `date_enregistrement` DATETIME NOT NULL,
  PRIMARY KEY (`utilisateur_id`, `adresse_id`),
  INDEX `fk_Localisation_Adresse1_idx` (`adresse_id` ASC) VISIBLE,
  INDEX `fk_Localisation_Utilisateur1_idx` (`utilisateur_id` ASC) VISIBLE,
  CONSTRAINT `fk_Localisation_Adresse1`
    FOREIGN KEY (`adresse_id`)
    REFERENCES `oc_pizza_db`.`Adresse` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Localisation_Utilisateur1`
    FOREIGN KEY (`utilisateur_id`)
    REFERENCES `oc_pizza_db`.`Utilisateur` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Role` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `titre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

CREATE TABLE IF NOT EXISTS `oc_pizza_db`.`Occupation` (
  `utilisateur_id` INT(10) UNSIGNED NOT NULL,
  `role_id` INT(10) UNSIGNED NOT NULL,
  `statut` VARCHAR(50) NOT NULL,
  `date_debut` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`utilisateur_id`, `role_id`),
  INDEX `fk_Occupation_Utilisateur1_idx` (`utilisateur_id` ASC) VISIBLE,
  INDEX `fk_Occupation_Role1_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_Occupation_Utilisateur1`
    FOREIGN KEY (`utilisateur_id`)
    REFERENCES `oc_pizza_db`.`Utilisateur` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Occupation_Role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `oc_pizza_db`.`Role` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
